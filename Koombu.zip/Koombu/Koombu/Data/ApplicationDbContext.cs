﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using Koombu.Models;
using Koombu.Models.Element;

namespace Koombu.Data
{
    public class ApplicationDbContext : IdentityDbContext<ApplicationUser>
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
               : base(options)
        {

        }

        public DbSet<Comment> Comments { get; set; }
        public DbSet<Group> Groups { get; set; }
        public DbSet<Post> Posts { get; set; }

        protected override void OnModelCreating(ModelBuilder builder)
        {
            base.OnModelCreating(builder);

            builder.Entity<Like>()
                .HasKey(t => new { t.PostId, t.UserId });

            builder.Entity<Like>()
                .HasOne(pt => pt.Post)
                .WithMany(p => p.Likes)
                .HasForeignKey(pt => pt.PostId);

            builder.Entity<Like>()
                .HasOne(pt => pt.User)
                .WithMany(t => t.Likes)
                .HasForeignKey(pt => pt.UserId);

            builder.Entity<Follow>()
                .HasKey(t => new { t.FollowerId, t.FollowingId });

            builder.Entity<Follow>()
                .HasOne(pt => pt.Follower)
                .WithMany(p => p.FollowerUsers)
                .HasForeignKey(pt => pt.FollowerId);

            builder.Entity<Follow>()
                .HasOne(pt => pt.Following)
                .WithMany(t => t.FollowingUsers)
                .HasForeignKey(pt => pt.FollowingId);

            builder.Entity<GroupUser>()
                .HasKey(t => new { t.GroupId, t.UserId });

            builder.Entity<GroupUser>()
                .HasOne(pt => pt.User)
                .WithMany(p => p.GroupUsers)
                .HasForeignKey(pt => pt.UserId);

            builder.Entity<GroupUser>()
                .HasOne(pt => pt.Group)
                .WithMany(t => t.GroupUsers)
                .HasForeignKey(pt => pt.GroupId);

            builder.Entity<Comment>().ToTable("Comment");
            builder.Entity<Group>().ToTable("Group");
            builder.Entity<Post>().ToTable("Post");
        }

        public DbSet<Koombu.Models.Element.Follow> Follow { get; set; }

        public DbSet<Koombu.Models.Element.Like> Like { get; set; }
        public DbSet<Koombu.Models.Element.GroupUser> GroupUser { get; set; }

        public DbSet<Koombu.Models.ApplicationUser> ApplicationUser { get; set; }
    }
}
