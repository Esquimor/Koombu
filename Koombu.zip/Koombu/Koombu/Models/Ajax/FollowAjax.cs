﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Koombu.Models.Ajax
{
    public class FollowAjax
    {
        public string FollowerId { get; set; }

        public string FollowingId { get; set; }
    }
}
