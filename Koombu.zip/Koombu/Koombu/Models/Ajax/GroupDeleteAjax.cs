﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Koombu.Models.Ajax
{
    public class GroupDeleteAjax
    {
        public string userId { get; set; }
        public int groupId { get; set; }
    }
}
