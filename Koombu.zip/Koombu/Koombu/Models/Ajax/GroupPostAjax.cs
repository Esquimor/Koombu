﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Koombu.Models.Ajax
{
    public class GroupPostAjax
    {
        public int grouId { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
    }
}
