﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Koombu.Models.Element;

namespace Koombu.Models.Ajax
{
    public class CommentAjax
    {
        public string Message { get; set; }

        public string userId { get; set; }
        public int postId { get; set; }
    }
}
