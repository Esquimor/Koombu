﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Koombu.Models.ManageViewModels
{
    public class IndexViewModel
    {

        [DisplayName("Prénom")]
        [StringLength(40, ErrorMessage = "Le prénom doit être inférieur à 40 caractéres")]
        [Required]
        public string FirstName { get; set; }

        [DisplayName("Nom")]
        [StringLength(40, ErrorMessage = "Le nom doit être inférieur à 40 caractéres")]
        [Required]
        public string LastName { get; set; }

        [DisplayName("Date de Naissance")]
        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        [Required]
        public DateTime DateOfBirth { get; set; }


        [DisplayName("Département")]
        [StringLength(40, ErrorMessage = "Le département doit être inférieur à 40 caractéres")]
        [Required]
        public string Departement { get; set; }

        [DisplayName("Titre")]
        [StringLength(40, ErrorMessage = "Le titre doit être inférieur à 40 caractéres")]
        [Required]
        public string Title { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        public string StatusMessage { get; set; }
    }
}
