﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Koombu.Models.Element
{
    public class Follow
    {
        public string FollowerId { get; set; }
        [ForeignKey("FollowerForeignKey")]
        public ApplicationUser Follower { get; set; }

        public string FollowingId { get; set; }
        [ForeignKey("FollowingForeignKey")]
        public ApplicationUser Following { get; set; }
    }
}
