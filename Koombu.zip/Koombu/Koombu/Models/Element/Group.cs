﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Threading.Tasks;

namespace Koombu.Models.Element
{
    public class Group
    {
        [Key] public int Id { get; set; }

        [DisplayName("Nom")]
        [StringLength(40, ErrorMessage = "Le nom doit être inférieur à 40 caractéres")]
        [Required]
        public string Name { get; set; }

        [DisplayName("Créateur")]
        public ApplicationUser User { get; set; }

        public List<GroupUser> GroupUsers { get; set; }
    }
}
