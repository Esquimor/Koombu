﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace Koombu.Models.Element
{
    public class Post
    {
        [Key] public int Id { get; set; }

        [DisplayName("Nom")]
        [StringLength(40, ErrorMessage = "Le nom doit être inférieur à 40 caractéres")]
        [Required]
        public String Content { get; set; }

        public string Attachement { get; set; }
        public string Image { get; set; }

        // Foreign Key

        public ApplicationUser User { get; set; }

        public Group Group { get; set; }

        public List<Like> Likes { get; set; }
        public List<Comment> Comments { get; set; }
    }
}
