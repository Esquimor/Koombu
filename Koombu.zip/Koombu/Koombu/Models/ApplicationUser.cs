﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Koombu.Models.Element;
using Microsoft.AspNetCore.Identity;

namespace Koombu.Models
{
    // Add profile data for application users by adding properties to the ApplicationUser class
    public class ApplicationUser : IdentityUser
    {
        [DisplayName("Prénom")]
        [StringLength(40, ErrorMessage = "Le prénom doit être inférieur à 40 caractéres")]
        public string FirstName { get; set; }

        [DisplayName("Nom")]
        [StringLength(40, ErrorMessage = "Le nom doit être inférieur à 40 caractéres")]
        public string LastName { get; set; }

        [DataType(DataType.Date)]
        [DisplayFormat(DataFormatString = "{0:dd/MM/yyyy}", ApplyFormatInEditMode = true)]
        public DateTime DateOfBirth { get; set; }


        [DisplayName("Département")]
        [StringLength(40, ErrorMessage = "Le département doit être inférieur à 40 caractéres")]
        public string Departement { get; set; }

        [DisplayName("Titre")]
        [StringLength(40, ErrorMessage = "Le titre doit être inférieur à 40 caractéres")]
        public string Title { get; set; }


        public List<Post> Posts { get; set; }


        public List<Like> Likes { get; set; }

        public List<GroupUser> GroupUsers { get; set; }

        public List<Follow> FollowerUsers { get; set; }
        public List<Follow> FollowingUsers { get; set; }

        public List<Comment> Comments { get; set; }
    }
}
