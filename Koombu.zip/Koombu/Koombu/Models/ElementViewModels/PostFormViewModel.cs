﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;
using Koombu.Models.Element;
using Microsoft.AspNetCore.Http;

namespace Koombu.Models.ElementViewModels
{
    public class PostFormViewModel
    {
        [DisplayName("Nom")]
        [StringLength(40, ErrorMessage = "Le nom doit être inférieur à 40 caractéres")]
        [Required]
        public String Content { get; set; }

        public IFormFile Attachement { get; set; }
        public IFormFile Image { get; set; }

        public List<Group> Group { get; set; }

        public int GroupId { get; set; }
    }
}
