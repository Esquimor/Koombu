﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Koombu.Data;
using Koombu.Models;
using Koombu.Models.Ajax;
using Koombu.Models.Element;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;


namespace Koombu.Controllers
{
    [Produces("application/json")]
    [Route("api/Groups")]
    public class ApiGroupsController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly UserManager<ApplicationUser> _userManager;

        public ApiGroupsController(
            UserManager<ApplicationUser> userManager,
            ApplicationDbContext context)
        {
            _userManager = userManager;
            _context = context;
        }

        // POST: api/Follows
        [HttpPost]
        public async Task<IActionResult> PostFollow([FromBody] GroupPostAjax groupPost)
        {
            var user = await _context.ApplicationUser.SingleOrDefaultAsync(p => p.FirstName == groupPost.firstName && p.LastName == groupPost.lastName);
            var group = await _context.Groups.SingleOrDefaultAsync(p => p.Id == groupPost.grouId);
            GroupUser groupUser = new GroupUser();
            groupUser.User = user;
            groupUser.Group = group;
            groupUser.UserId = user.Id;
            groupUser.GroupId = groupPost.grouId;
            _context.GroupUser.Add(groupUser);
            await _context.SaveChangesAsync();
            return Ok();
        }
        // DELETE: api/Follows
        [HttpDelete]
        public async Task<IActionResult> DeleteFollow([FromBody] GroupDeleteAjax groupDelete)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var groupUser = await _context.GroupUser.SingleOrDefaultAsync(g => g.Group.Id == groupDelete.groupId && g.User.Id == groupDelete.userId);

            _context.GroupUser.Remove(groupUser);
            await _context.SaveChangesAsync();

            return Ok();
        }

        private bool FollowExists(string id)
        {
            return _context.Follow.Any(e => e.FollowerId == id);
        }
    }
}